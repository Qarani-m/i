#include <linux/init.h>
#include <linux/slab.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/semaphore.h>
#include <linux/kthread.h>
#include <linux/timekeeping.h>
#include <linux/sched/signal.h>
#include <linux/mm_types.h>
#include <linux/mm.h>
#include <linux/hrtimer.h>
#include <linux/jiffies.h>

static int pid = 1;
module_param(pid, int, 0);
u64 start_time;
static struct task_struct *task;
static struct hrtimer my_hrtimer;
static int exit_flag = 0;

static unsigned long timer_interval_ns = 10e9; // 10-second timer

int ptep_test_and_clear_young(struct vm_area_struct *vma, unsigned long addr, pte_t *ptep) {
    int ret = 0;
    if (pte_young(*ptep))
        ret = test_and_clear_bit(_PAGE_BIT_ACCESSED, (unsigned long *)&ptep->pte);
    return ret;
}

int find_pte(struct task_struct *task) {
    struct vm_area_struct *vma;
    unsigned long address;
    pgd_t *pgd;
    p4d_t *p4d;
    pud_t *pud;
    pmd_t *pmd;
    pte_t *ptep, pte;

    struct mm_struct *mm = task->mm;

    if (mm) {
        vma = task->mm->mmap_base;
        int vma_counter = 0;
        int accessed = 0;
        int no_accessed = 0;
        int counter = 0; // found in the memory
        int failed = 0;

        while (vma) {
            unsigned long end = vma->vm_end;

            // iterate each vma
            for (address = vma->vm_start; address < vma->vm_end; address += PAGE_SIZE) {
                pgd = pgd_offset(mm, address);
                if (pgd_none(*pgd) || pgd_bad(*pgd)) {
                    failed++;
                }
                p4d = p4d_offset(pgd, address);
                if (p4d_none(*p4d) || p4d_bad(*p4d)) {
                    failed++;
                }
                pud = pud_offset(p4d, address);
                if (pud_none(*pud) || pud_bad(*pud)) {
                    failed++;
                }
                pmd = pmd_offset(pud, address);
                if (pmd_none(*pmd) || pmd_bad(*pmd)) {
                    failed++;
                }
                ptep = pte_offset_map(pmd, address);
                if (!ptep) {
                    failed++;
                }
                pte = *ptep;
                if (ptep_test_and_clear_young(vma, address, ptep) == 1) {
                    accessed++;
                } else {
                    no_accessed++;
                }
                if (pte_present(pte) == 1) {
                    counter++;
                } else {
                    failed++;
                }
            }

            vma_counter++;
            vma = vma->vm_end;
        }

        int wss_size = accessed * 4;
        int rss_size = counter * 4;
        int swap_size = failed * 4;
        printk("PID = %d: RSS = %dKB, WSS = %dKB, SWAP = %dKB", pid, rss_size, wss_size, swap_size);
    }

    return 0;
}

static enum hrtimer_restart no_restart_callback(struct hrtimer *timer) {
    exit_flag++;
    ktime_t currtime, interval;
    currtime = ktime_get();
    interval = ktime_set(0, timer_interval_ns);
    hrtimer_forward(timer, currtime, interval);
    find_pte(task);
    printk("%d", exit_flag);
    return HRTIMER_RESTART;
}

static int __init mm_init(void) {
    printk(KERN_INFO "initialize");
    ktime_t ktime;
    ktime = ktime_set(0, timer_interval_ns);
    hrtimer_init(&my_hrtimer, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
    my_hrtimer.function = &no_restart_callback;
    //start_time = jiffies;
    hrtimer_start(&my_hrtimer, ktime, HRTIMER_MODE_REL);
    return 0;
}

void __exit mm_exit(void) {
    int ret;
    ret = hrtimer_cancel(&my_hrtimer);
    if (ret)
        printk("The timer was still in use...\n");
    printk("HR Timer module uninstalling\n");
}

MODULE_LICENSE("GPL");
module_init(mm_init);
module_exit(mm_exit);
